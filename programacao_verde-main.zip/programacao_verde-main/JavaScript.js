function mudartexto() {
    //Modificando o botão via id
    document.getElementById("botao").innerHTML = "Botao do pao!"
    alert("N foi dessa vez")
}